from flask import Flask, render_template, request

app = Flask(__name__)

@app.route("/",methods=['GET','POST'])
def main():
    return render_template("index.html")


@app.route("/m3",methods=['GET','POST'])
def main2():
    data = dict(request.form)
    print(data)
    return "my name is flask"

@app.route("/contact",methods=['GET','POST'])
def main3():
    return "contact details - Wiley Inc. \ Mumbai"

if __name__=="__main__":
    app.run(debug=True)

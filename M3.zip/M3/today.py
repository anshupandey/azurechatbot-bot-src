def main2(a,b=5,k=3):
    """
    This function adds two numbers or two string
    >> main(4,3)
    >> 7
    """
    c = a+b
    c = c*k
    return c


def hello(a,b):
    return a*b

class A:
    x = 5
    y = 6
    _w = 10
    __q = 11
    def myfun(self,a,b):
        c = a+b
        return c